----------------------------------------------------------------------
The program is used to compute the area of the triangle.
Users should enter the sides of the triangle, with whilte space
separating the each side. After input, the program will write the
ouput into the file.
----------------------------------------------------------------------

1. 姓名: 龔鈺閎

2. 學號: 408410046

3. e-mail: yuhongg374@gmail.com

4. 完成的作業項目: C++, Java, Python, makefile

5. Bouns內容(助教會依Bonus內容酌量給分): 
    三個程式都會分別將輸出寫到 "cpp_output.txt" "java_output.txt" "python_output.txt"

6. Reference
    C++:
        寫入檔案: http://www2.lssh.tp.edu.tw/~hlf/class-1/lang-c/c++file.htm
        開根號: https://coder.tw/?p=357

    Java:
        sqrt 函式參考: http://tw.gitbook.net/java/lang/math_sqrt.html
        寫入檔案參考影片: https://www.youtube.com/watch?v=wXSZcuQLklk
        輸入資料處理: https://medium.com/@shivamrawat_756/how-to-get-integers-separated-by-space-in-java-e54034b8ab6e

    Python:
        寫入檔案參考: https://medium.com/ccclub/ccclub-python-for-beginners-tutorial-bf0648108581
        寫檔換行: https://www.cnblogs.com/SheilaSun/p/4380933.html


