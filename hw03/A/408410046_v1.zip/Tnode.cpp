#include <iostream>

class Tnode
{
public:
    Tnode *left, *right;
    int val;
};
typedef Tnode *TnodePtr;