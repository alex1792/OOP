-----------------------------------------------------------------------------
The program is to inplement a stack(LIFO). First, the users will enter the
mode. "1" represents "push into stack", "2" represents "pop from stack", and
"3" represents "empty", which checks the stack is empty or not. If you want to
quit, then enter "-1" to quit the program. After that, users input the value 
they want until they quit the program. Lastly, the progam will pop out all the
values in stack and print it on the screen.
-----------------------------------------------------------------------------

1. 姓名: 龔鈺閎

2. 學號: 408410046

3. e-mail: yuhongg374@gmail.com

4. 完成的作業項目: Stack.cpp, Node.cpp, main_stack.cpp,makefile

5. Bouns內容(助教會依Bonus內容酌量給分): 
    無

6. Reference
   makefile: https://mropengate.blogspot.com/2018/01/makefile.html

